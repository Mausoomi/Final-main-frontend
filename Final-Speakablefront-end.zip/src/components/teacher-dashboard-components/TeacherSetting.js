import React from 'react'

const TeacherSetting = () => {
  return (
    <div>TeacherSetting</div>
  )
}

export default TeacherSetting